import {
  ShoppingBag,
} from "lucide-react";

const OrderSummary = ({
  order = {},
}) => {
const { items = [] } = order;

const subtotal = items.reduce(
  (sum, item) =>
    sum + (item.total || item.price * item.quantity),
  0
);

const discount = order.discount || 0;

const deliveryFee =
  order.deliveryFee ??
  (subtotal >= 499 ? 0 : 40);

const taxes =
  order.taxes ??
  Math.round(subtotal * 0.05);

const total =
  subtotal +
  deliveryFee +
  taxes -
  discount;

  return (
    <section
      className="
        rounded-2xl
        border
        border-slate-200
        bg-white
        shadow-sm
      "
    >
      {/* Header */}
      <div className="border-b border-slate-100 px-6 py-5">
        <div className="flex items-center gap-3">
          <div
            className="
              flex
              h-11
              w-11
              items-center
              justify-center
              rounded-xl
              bg-green-50
              text-green-600
            "
          >
            <ShoppingBag size={22} />
          </div>

          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Order Summary
            </h2>

            <p className="text-sm text-slate-500">
              {items.length} Items Ordered
            </p>
          </div>
        </div>
      </div>

      {/* Items */}
      <div className="divide-y divide-slate-100">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex items-center gap-4 px-6 py-4"
          >
            <img
              src={item.image}
              alt={item.name}
              className="
                h-16
                w-16
                rounded-xl
                object-cover
                border
                border-slate-200
              "
            />

            <div className="min-w-0 flex-1">
              <h3 className="truncate font-semibold text-slate-900">
                {item.name}
              </h3>

              <p className="mt-1 text-sm text-slate-500">
                Qty : {item.quantity}
              </p>
            </div>

            <div className="text-right">
              <p className="font-bold text-slate-900">
                ₹{item.total}
              </p>

              <p className="mt-1 text-xs text-slate-500">
                ₹{item.price} each
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Bill */}
      <div className="border-t border-slate-100 px-6 py-5">
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-500">
              Subtotal
            </span>

            <span className="font-medium">
              ₹{subtotal}
            </span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">
              Delivery Fee
            </span>

            <span className="font-medium">
              ₹{deliveryFee}
            </span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">
              Taxes
            </span>

            <span className="font-medium">
              ₹{taxes}
            </span>
          </div>

          {discount > 0 && (
            <div className="flex justify-between text-green-600">
              <span>
                Discount
              </span>

              <span>
                -₹{discount}
              </span>
            </div>
          )}
        </div>

        <div className="my-5 border-t border-dashed border-slate-200" />

        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-slate-900">
            Total
          </span>

          <span className="text-2xl font-bold text-green-600">
            ₹{total}
          </span>
        </div>
      </div>
    </section>
  );
};

export default OrderSummary;