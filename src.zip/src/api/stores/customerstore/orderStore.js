import { create } from "zustand";

const initialOrder = {
  // Customer Details
  customer_name: "",
  customer_phone: "",

  // Ordered Items
  items: [],

  // Order Type
  order_type: "delivery", // delivery | takeaway | dine-in

  // Payment
  payment_method: "COD", // COD | CASH | ONLINE | UPI_MANUAL

  // Delivery Address
  delivery_address: "",
  latitude: null,
  longitude: null,
  mohalla: "",

  // Offers
  coupon_code: "",
  discount_code: "",

  // Schedule
  is_scheduled: false,
  scheduled_for: null,

  // Frontend Only (Not sent to API)
  store: {
    id: "",
    name: "",
    logo: "",
  },

  pricing: {
    subtotal: 0,
    delivery_fee: 0,
    tax: 0,
    discount: 0,
    total: 0,
  },
};

const useOrderStore = create((set, get) => ({
  ...initialOrder,
    // ==========================
  // Customer
  // ==========================

  setCustomer: ({ customer_name, customer_phone }) =>
    set({
      customer_name,
      customer_phone,
    }),

  updateCustomerName: (customer_name) =>
    set({ customer_name }),

  updateCustomerPhone: (customer_phone) =>
    set({ customer_phone }),

  // ==========================
  // Store (Frontend Only)
  // ==========================

  setStore: (store) =>
    set({
      store: {
        id: store.id ?? "",
        name: store.name ?? "",
        logo: store.logo ?? "",
      },
    }),

  // ==========================
  // Order Type
  // ==========================

  setOrderType: (order_type) =>
    set({
      order_type,
    }),

  // ==========================
  // Payment
  // ==========================

  setPaymentMethod: (payment_method) =>
    set({
      payment_method,
    }),

  // ==========================
  // Delivery Address
  // ==========================

  setDeliveryAddress: ({
    delivery_address,
    latitude,
    longitude,
    mohalla,
  }) =>
    set({
      delivery_address,
      latitude,
      longitude,
      mohalla,
    }),

  clearDeliveryAddress: () =>
    set({
      delivery_address: "",
      latitude: null,
      longitude: null,
      mohalla: "",
    }),
      // ==========================
  // Order Items
  // ==========================

  setItems: (items) =>
    set({
      items,
    }),

  addItem: (item) =>
    set((state) => {
      const existingIndex = state.items.findIndex(
        (i) => i.product_id === item.product_id
      );

      if (existingIndex !== -1) {
        const items = [...state.items];

        items[existingIndex] = {
          ...items[existingIndex],
          quantity:
            items[existingIndex].quantity + item.quantity,
        };

        return { items };
      }

      return {
        items: [
          ...state.items,
          {
            product_id: item.product_id,
            quantity: item.quantity,
          },
        ],
      };
    }),

  updateItemQuantity: (product_id, quantity) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.product_id === product_id
          ? {
              ...item,
              quantity,
            }
          : item
      ),
    })),

  increaseItemQuantity: (product_id) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.product_id === product_id
          ? {
              ...item,
              quantity: item.quantity + 1,
            }
          : item
      ),
    })),

  decreaseItemQuantity: (product_id) =>
    set((state) => ({
      items: state.items
        .map((item) =>
          item.product_id === product_id
            ? {
                ...item,
                quantity: Math.max(
                  1,
                  item.quantity - 1
                ),
              }
            : item
        )
        .filter((item) => item.quantity > 0),
    })),

  removeItem: (product_id) =>
    set((state) => ({
      items: state.items.filter(
        (item) => item.product_id !== product_id
      ),
    })),

  clearItems: () =>
    set({
      items: [],
    }),

  getItem: (product_id) =>
    get().items.find(
      (item) => item.product_id === product_id
    ),

  getItemQuantity: (product_id) =>
    get().items.find(
      (item) => item.product_id === product_id
    )?.quantity || 0,
      // ==========================
  // Coupon & Discount
  // ==========================

  setCouponCode: (coupon_code) =>
    set({
      coupon_code,
      discount_code: "",
    }),

  clearCouponCode: () =>
    set({
      coupon_code: "",
    }),

  setDiscountCode: (discount_code) =>
    set({
      discount_code,
      coupon_code: "",
    }),

  clearDiscountCode: () =>
    set({
      discount_code: "",
    }),

  // ==========================
  // Schedule
  // ==========================

  setSchedule: ({
    is_scheduled,
    scheduled_for,
  }) =>
    set({
      is_scheduled,
      scheduled_for,
    }),

  clearSchedule: () =>
    set({
      is_scheduled: false,
      scheduled_for: null,
    }),

  // ==========================
  // Pricing (Frontend Only)
  // ==========================

  setPricing: (pricing) =>
    set((state) => ({
      pricing: {
        ...state.pricing,
        ...pricing,
      },
    })),

  // ==========================
  // API Payload
  // ==========================

  getPayload: () => {
    const state = get();

    return {
      customer_name: state.customer_name,
      customer_phone: state.customer_phone,

      items: state.items.map((item) => ({
        product_id: item.product_id,
        quantity: item.quantity,
      })),

      payment_method: state.payment_method,
      order_type: state.order_type,

      delivery_address: state.delivery_address,
      latitude: state.latitude,
      longitude: state.longitude,
      mohalla: state.mohalla,

      coupon_code:
        state.coupon_code || undefined,

      discount_code:
        state.discount_code || undefined,

      is_scheduled: state.is_scheduled,

      scheduled_for: state.is_scheduled
        ? state.scheduled_for
        : undefined,
    };
  },

  // ==========================
  // Reset
  // ==========================

  resetOrder: () =>
    set({
      ...initialOrder,
    }),
}));

export default useOrderStore;